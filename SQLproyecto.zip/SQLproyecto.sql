create database sistema_gestion

create table Encargados(
id int identity,
[user] nvarchar(20),
[password] nvarchar (100)
)

insert into Encargados([user], [password]) values ('admin', 'Admin123')

select * from Encargados

create table Usuarios(
id int identity,
Nombre nvarchar(20),
Apellido nvarchar(20),
[User] nvarchar(20),
[Password] nvarchar (100)
)

-- Crear tabla Unidades
Drop table Unidades
CREATE TABLE Unidades (
    IdUnidad NVARCHAR(20) PRIMARY KEY, -- Valor ingresado manualmente, debe ser �nico
    Placas NVARCHAR(20),
    Marca NVARCHAR(50),
    Modelo NVARCHAR(50),
    NoCentro NVARCHAR(20),
    NoSerie NVARCHAR(50),
    Localidad NVARCHAR(100)
);

-- Crear tabla Remolques
Drop table Remolques
CREATE TABLE Remolques (
    IdRemolques NVARCHAR(20) PRIMARY KEY, -- Valor ingresado manualmente, debe ser �nico
    Placas NVARCHAR(20),
    Marca NVARCHAR(50),
    Modelo NVARCHAR(50),
    NoCentro NVARCHAR(20),
    NoSerie NVARCHAR(50),
    Localidad NVARCHAR(100)
);

INSERT INTO Unidades (IdUnidad, Placas, Marca, Modelo, NoCentro, NoSerie, Localidad)
VALUES
('U-53045', 'YQY-5320', 'International', '2020', '200222', '8WGGB23YHPYN1754', 'Hermosillo'),
('U-53031', 'YVC-5122', 'International', '2020', '200222', '9WGYB25YHLMN1760', 'Hermosillo'),
('U-53059', 'YWE-5225', 'International', '2020', '200222', '7YGUB26OHPLN1851', 'Hermosillo'),
('U-53060', 'YWQ-5030', 'International', '2020', '200222', '5WUTR13YHPDF1752', 'Hermosillo'),
('U-53044', 'YRW-2321', 'International', '2020', '200222', '3TGYU27YHNPLM1655', 'Hermosillo'),
('U-52942', 'YTD-3026', 'International', '2020', '200222', '6QSGB30L�PYNB1845', 'Hermosillo'),
('U-55955', 'YUE-3521', 'International', '2020', '200222', '9UMGT35LKPFDS1312', 'Hermosillo'),
('U-57068', 'YEI-6010', 'International', '2020', '200222', '2RYYU40YHHGW1457', 'Hermosillo'),
('U-57069', 'YDE-6112', 'International', '2020', '200222', '1WSAB23YHBYN1328', 'Hermosillo');

INSERT INTO Remolques (IdRemolques, Placas, Marca, Modelo, NoCentro, NoSerie, Localidad)
VALUES
('R-680', '5-RW-1214', 'Fraba', '2018', '200222', '2B44YDR17FG541', 'Hermosillo'),
('R-725', '2-RY-1415', 'Fraba', '2018', '200222', '3B45YDR17FT678', 'Hermosillo'),
('R-415', '1-WE-1456', 'Fraba', '2018', '200222', '2R46MNR16QY654', 'Hermosillo'),
('R-520', '3-RW-1553', 'Fraba', '2018', '200222', '3R48RBV14HF533', 'Hermosillo'),
('R-466', '4-RT-1020', 'Fraba', '2018', '200222', '4T46UDR20FG876', 'Hermosillo'),
('R-909', '5-EZ-4567', 'Fraba', '2018', '200222', '5T55WER20FG621', 'Hermosillo'),
('R-845', '5-RQ-5432', 'Fraba', '2018', '200222', '6J40YWT56EG123', 'Hermosillo'),
('R-378', '5-VF-5890', 'Fraba', '2018', '200222', '4B77IPL87EG345', 'Hermosillo'),
('R-550', '4-YG-1269', 'Fraba', '2018', '200222', '9P27LDM19FG429', 'Hermosillo'),
('R-710', '4-RE-6454', 'Fraba', '2018', '200222', '8B94EDL17QW540', 'Hermosillo'),
('R-950', '2-WR-1598', 'Fraba', '2018', '200222', '9B70Y�L65JL698', 'Hermosillo');

select * from Unidades
select * from Remolques


drop table documentacion
CREATE TABLE documentacion (
    id VARCHAR(20),    -- Aqu� estar� el id de unidad o remolque
    tipo_documentacion VARCHAR(100) NOT NULL,
    fecha_emitida DATE NOT NULL,
    fecha_vencida DATE NOT NULL,
    alerta AS (
        CASE 
            WHEN DATEDIFF(day, GETDATE(), fecha_vencida) > 30 THEN 'Vigente'
            WHEN DATEDIFF(day, GETDATE(), fecha_vencida) BETWEEN 1 AND 10 THEN 'Pr�ximo a vencer'
            WHEN DATEDIFF(day, GETDATE(), fecha_vencida) <= 0 THEN 'Vencido'
            ELSE 'Vigente'
        END
    )
);

truncate table documentacion

-- Insertar documentaci�n para todas las unidades con alertas variadas
INSERT INTO documentacion (id, tipo_documentacion, fecha_emitida, fecha_vencida)
SELECT 
    id_unidad, 
    doc,
    DATEADD(DAY, -ABS(CHECKSUM(NEWID()) % 90), GETDATE()) AS fecha_emitida,
    CASE ABS(CHECKSUM(NEWID()) % 3)
        WHEN 0 THEN DATEADD(DAY, -ABS(CHECKSUM(NEWID()) % 30), GETDATE())   -- VENCIDO
        WHEN 1 THEN DATEADD(DAY, ABS(CHECKSUM(NEWID()) % 10), GETDATE())    -- PR�XIMO A VENCER
        ELSE DATEADD(DAY, ABS(CHECKSUM(NEWID()) % 90) + 31, GETDATE())       -- VIGENTE
    END AS fecha_vencida
FROM 
(
    SELECT id_unidad = value 
    FROM (VALUES 
        ('U-53045'), ('U-53031'), ('U-53059'), 
        ('U-53060'), ('U-53044'), ('U-52942'), 
        ('U-55955'), ('U-57068'), ('U-57069')
    ) AS unidades(value)
) AS u
CROSS JOIN 
(
    SELECT doc = value 
    FROM (VALUES 
        ( 'Tarjeta de Circulacion'),
		( 'Permiso de Carga Federal'),
		( 'Permiso del engomado doblemente articulado'),
		( 'Factura'),
		( 'Dictamen de la Fisico Mecanica'),
		( 'Emisiones contaminantes'),
		( 'Poliza del seguro')
    ) AS documentos(value)
) AS d;



-- Insertar documentaci�n para todos los remolques con alertas variadas
INSERT INTO documentacion (id, tipo_documentacion, fecha_emitida, fecha_vencida)
SELECT 
    id_remolque, 
    doc,
    DATEADD(DAY, -ABS(CHECKSUM(NEWID()) % 90), GETDATE()) AS fecha_emitida,
    CASE ABS(CHECKSUM(NEWID()) % 3)
        WHEN 0 THEN DATEADD(DAY, -ABS(CHECKSUM(NEWID()) % 30), GETDATE())   -- VENCIDO
        WHEN 1 THEN DATEADD(DAY, ABS(CHECKSUM(NEWID()) % 10), GETDATE())    -- PR�XIMO A VENCER
        ELSE DATEADD(DAY, ABS(CHECKSUM(NEWID()) % 90) + 31, GETDATE())       -- VIGENTE
    END AS fecha_vencida
FROM 
(
    SELECT id_remolque = value 
    FROM (VALUES 
        ('R-680'), ('R-725'), ('R-415'), 
        ('R-520'), ('R-466'), ('R-909'), 
        ('R-845'), ('R-378'), ('R-550')
    ) AS remolques(value)
) AS r
CROSS JOIN 
(
    SELECT doc = value 
    FROM (VALUES 
        ('Tarjeta de Circulacion'),
        ('Permiso de Carga Federal'),
        ('Permiso del engomado doblemente articulado'),
        ('Factura'),
        ('Dictamen de la Fisico Mecanica')
    ) AS documentos(value)
) AS d;

INSERT INTO documentacion (id, tipo_documentacion, fecha_emitida, fecha_vencida) VALUES
-- Para la unidad U-53045
('U-53045', 'Tarjeta de Circulacion', '2025-04-01', '2025-07-15'),
('U-53045', 'Permiso de Carga Federal', '2025-03-15', '2025-06-25'),
('U-53045', 'Permiso del engomado doblemente articulado', '2025-04-10', '2025-07-10'),
('U-53045', 'Dictamen de la Fisico Mecanica', '2025-04-05', '2025-07-05'),
('U-53045', 'Tarjeta de Circulacion', '2025-03-20', '2025-07-20'),
('U-53045', 'Permiso de Carga Federal', '2025-03-18', '2025-06-30'),
('U-53045', 'Factura', '2025-04-01', '2025-07-01'),
('U-53045', 'Tarjeta de Circulacion', '2025-04-02', '2025-07-02'),

-- Para la unidad U-53031
('U-53031', 'Tarjeta de Circulacion', '2025-04-01', '2025-07-15'),
('U-53031', 'Permiso de Carga Federal', '2025-03-15', '2025-06-25'),
('U-53031', 'Permiso del engomado doblemente articulado', '2025-04-10', '2025-07-10'),
('U-53031', 'Dictamen de la Fisico Mecanica', '2025-04-05', '2025-07-05'),
('U-53031', 'Tarjeta de Circulacion', '2025-03-20', '2025-07-20'),
('U-53031', 'Permiso de Carga Federal', '2025-03-18', '2025-06-30'),
('U-53031', 'Factura', '2025-04-01', '2025-07-01'),
('U-53031', 'Tarjeta de Circulacion', '2025-04-02', '2025-07-02'),

-- Para el remolque R-680
('R-680', 'Tarjeta de Circulacion', '2025-04-01', '2025-07-15'),
('R-680', 'Permiso de Carga Federal', '2025-03-15', '2025-06-25'),
('R-680', 'Permiso del engomado doblemente articulado', '2025-04-10', '2025-07-10'),
('R-680', 'Dictamen de la Fisico Mecanica', '2025-04-05', '2025-07-05'),
('R-680', 'Tarjeta de Circulacion', '2025-03-20', '2025-07-20'),
('R-680', 'Permiso de Carga Federal', '2025-03-18', '2025-06-30'),
('R-680', 'Factura', '2025-04-01', '2025-07-01'),
('R-680', 'Tarjeta de Circulacion', '2025-04-02', '2025-07-02')

-- Puedes continuar con el resto de IDs igual.
;

INSERT INTO documentacion (id, tipo_documentacion, fecha_emitida, fecha_vencida) VALUES
-- Documentos vencidos para la unidad U-53045
('U-53045', 'Seguro Obligatorio', '2024-01-01', '2025-05-01'),
('U-53045', 'Verificaci�n Vehicular', '2024-12-15', '2025-06-10'),

-- Documentos vencidos para la unidad U-53031
('U-53031', 'Seguro Obligatorio', '2024-01-01', '2025-04-20'),
('U-53031', 'Verificaci�n Vehicular', '2024-12-15', '2025-05-15'),

-- Documentos vencidos para el remolque R-680
('R-680', 'Seguro Obligatorio', '2024-01-01', '2025-05-05'),
('R-680', 'Verificaci�n Vehicular', '2024-12-15', '2025-05-10');

select * from documentacion order by id


CREATE TABLE StockVehiculos (
    id_stock INT PRIMARY KEY IDENTITY(1,1),
    id_vehiculo VARCHAR(20) NOT NULL,
    tipo_vehiculo VARCHAR(20) CHECK (tipo_vehiculo IN ('Unidad', 'Remolque')),
    cantidad INT NOT NULL DEFAULT 1,
    fecha_registro DATETIME DEFAULT GETDATE(),
    estado VARCHAR(50) DEFAULT 'Disponible',
    observaciones VARCHAR(255)
);

truncate table StockVehiculos

INSERT INTO StockVehiculos (id_vehiculo, tipo_vehiculo, cantidad, estado, observaciones)
SELECT 
    u.IdUnidad,
    'Unidad',
    1,
    CASE 
        WHEN obs IN ('En revisi�n mec�nica', 'Falta reparaci�n') THEN 'Fuera de servicio'
        ELSE 'Disponible'
    END AS estado,
    obs AS observaciones
FROM Unidades u
CROSS APPLY (
    SELECT 
        CASE ABS(CHECKSUM(NEWID())) % 5
            WHEN 0 THEN 'Sin observaciones'
            WHEN 1 THEN 'Falta mantenimiento'
            WHEN 2 THEN 'Servicio pendiente'
            WHEN 3 THEN 'En revisi�n mec�nica'
            ELSE 'Falta reparaci�n'
        END AS obs
) AS ObservacionAleatoria;

INSERT INTO StockVehiculos (id_vehiculo, tipo_vehiculo, cantidad, estado, observaciones)
SELECT 
    r.IdRemolques,
    'Remolque',
    1,
    CASE 
        WHEN obs IN ('En revisi�n mec�nica', 'Falta reparaci�n') THEN 'Fuera de servicio'
        ELSE 'Disponible'
    END AS estado,
    obs AS observaciones
FROM Remolques r
CROSS APPLY (
    SELECT 
        CASE ABS(CHECKSUM(NEWID())) % 5
            WHEN 0 THEN 'Sin observaciones'
            WHEN 1 THEN 'Falta mantenimiento'
            WHEN 2 THEN 'Servicio pendiente'
            WHEN 3 THEN 'En revisi�n mec�nica'
            ELSE 'Falta reparaci�n'
        END AS obs
) AS ObservacionAleatoria;

select * from StockVehiculos


CREATE TRIGGER trg_ActualizarEstadoPorObservacion
ON StockVehiculos
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE sv
    SET estado = 
        CASE 
            WHEN i.observaciones IN ('En revisi�n mec�nica', 'Falta reparaci�n') THEN 'Fuera de servicio'
            ELSE 'Disponible'
        END
    FROM StockVehiculos sv
    INNER JOIN inserted i ON sv.id_stock = i.id_stock
    -- Solo actualizamos si se modific� la observaci�n
    WHERE i.observaciones IS NOT NULL;
END;